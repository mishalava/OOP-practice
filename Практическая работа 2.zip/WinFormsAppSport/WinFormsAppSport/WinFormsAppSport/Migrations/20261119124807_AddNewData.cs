﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WinFormsAppSport.Migrations
{
    /// <inheritdoc />
    public partial class AddNewData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "acceleration",
                table: "Workouts",
                type: "REAL",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "avgSpeed",
                table: "Workouts",
                type: "REAL",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "maxSpeed",
                table: "Workouts",
                type: "REAL",
                nullable: false,
                defaultValue: 0.0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "acceleration",
                table: "Workouts");

            migrationBuilder.DropColumn(
                name: "avgSpeed",
                table: "Workouts");

            migrationBuilder.DropColumn(
                name: "maxSpeed",
                table: "Workouts");
        }
    }
}
